package com.seclass.ccc.views;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.seclass.ccc.R;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

public class MainActivity_time extends AppCompatActivity {

    private Button mScheduleButton;
    private Button mTimetableButton;
    private Button mMessageButton;
    public SQLiteDatabase db = null;
    private TextView monday[] = new TextView[12];
    private TextView tuesday[] = new TextView[12];
    private TextView wednesday[] = new TextView[12];
    private TextView thursday[] = new TextView[12];
    private TextView friday[] = new TextView[12];

    public Cursor cursor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_timetable);
        DBManager manager = DBManager.getInstance(getApplicationContext());
        db = DBManager.getInstance(getApplicationContext()).getWeeklyDB();

        mTimetableButton = (Button) findViewById(R.id.timetable_button);
        mScheduleButton = (Button) findViewById(R.id.schedule_button);
        mMessageButton = (Button) findViewById(R.id.messenger_button);

        mTimetableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity_time.this, ScheduleActivity.class);
                startActivity(intent);
            }
        });

        mScheduleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity_time.this, Scheduler.class);
                startActivity(intent);
            }
        });

        mMessageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity_time.this, MainActivity.class);
                startActivity(intent);
            }
        });

        monday[0] = (TextView) findViewById(R.id.monday0);
        monday[1] = (TextView) findViewById(R.id.monday1);
        monday[2] = (TextView) findViewById(R.id.monday2);
        monday[3] = (TextView) findViewById(R.id.monday3);
        monday[4] = (TextView) findViewById(R.id.monday4);
        monday[5] = (TextView) findViewById(R.id.monday5);
        monday[6] = (TextView) findViewById(R.id.monday6);
        monday[7] = (TextView) findViewById(R.id.monday7);
        monday[8] = (TextView) findViewById(R.id.monday8);
        monday[9] = (TextView) findViewById(R.id.monday9);
        monday[10] = (TextView) findViewById(R.id.monday10);
        monday[11] = (TextView) findViewById(R.id.monday11);
        tuesday[0] = (TextView) findViewById(R.id.tuesday0);
        tuesday[1] = (TextView) findViewById(R.id.tuesday1);
        tuesday[2] = (TextView) findViewById(R.id.tuesday2);
        tuesday[3] = (TextView) findViewById(R.id.tuesday3);
        tuesday[4] = (TextView) findViewById(R.id.tuesday4);
        tuesday[5] = (TextView) findViewById(R.id.tuesday5);
        tuesday[6] = (TextView) findViewById(R.id.tuesday6);
        tuesday[7] = (TextView) findViewById(R.id.tuesday7);
        tuesday[8] = (TextView) findViewById(R.id.tuesday8);
        tuesday[9] = (TextView) findViewById(R.id.tuesday9);
        tuesday[10] = (TextView) findViewById(R.id.tuesday10);
        tuesday[11] = (TextView) findViewById(R.id.tuesday11);
        wednesday[0] = (TextView) findViewById(R.id.wednesday0);
        wednesday[1] = (TextView) findViewById(R.id.wednesday1);
        wednesday[2] = (TextView) findViewById(R.id.wednesday2);
        wednesday[3] = (TextView) findViewById(R.id.wednesday3);
        wednesday[4] = (TextView) findViewById(R.id.wednesday4);
        wednesday[5] = (TextView) findViewById(R.id.wednesday5);
        wednesday[6] = (TextView) findViewById(R.id.wednesday6);
        wednesday[7] = (TextView) findViewById(R.id.wednesday7);
        wednesday[8] = (TextView) findViewById(R.id.wednesday8);
        wednesday[9] = (TextView) findViewById(R.id.wednesday9);
        wednesday[10] = (TextView) findViewById(R.id.wednesday10);
        wednesday[11] = (TextView) findViewById(R.id.wednesday11);
        thursday[0] = (TextView) findViewById(R.id.thursday0);
        thursday[1] = (TextView) findViewById(R.id.thursday1);
        thursday[2] = (TextView) findViewById(R.id.thursday2);
        thursday[3] = (TextView) findViewById(R.id.thursday3);
        thursday[4] = (TextView) findViewById(R.id.thursday4);
        thursday[5] = (TextView) findViewById(R.id.thursday5);
        thursday[6] = (TextView) findViewById(R.id.thursday6);
        thursday[7] = (TextView) findViewById(R.id.thursday7);
        thursday[8] = (TextView) findViewById(R.id.thursday8);
        thursday[9] = (TextView) findViewById(R.id.thursday9);
        thursday[10] = (TextView) findViewById(R.id.thursday10);
        thursday[11] = (TextView) findViewById(R.id.thursday11);
        friday[0] = (TextView) findViewById(R.id.friday0);
        friday[1] = (TextView) findViewById(R.id.friday1);
        friday[2] = (TextView) findViewById(R.id.friday2);
        friday[3] = (TextView) findViewById(R.id.friday3);
        friday[4] = (TextView) findViewById(R.id.friday4);
        friday[5] = (TextView) findViewById(R.id.friday5);
        friday[6] = (TextView) findViewById(R.id.friday6);
        friday[7] = (TextView) findViewById(R.id.friday7);
        friday[8] = (TextView) findViewById(R.id.friday8);
        friday[9] = (TextView) findViewById(R.id.friday9);
        friday[10] = (TextView) findViewById(R.id.friday10);
        friday[11] = (TextView) findViewById(R.id.friday11);

        setWeekly(db);
    }

    public void setWeekly(SQLiteDatabase db){
        for(int i=0;i<12;i++){
            String num = String.valueOf(i);
            cursor = db.rawQuery("select * from 'weekly' where time = ?", new String[]{num});
            cursor.moveToNext();
            if(cursor.getString(0).equals("")){
                this.monday[i].setTextColor(Color.WHITE);
                this.monday[i].setText("가나다라마바사아자차");
            }
            else {
                this.monday[i].setTextColor(Color.WHITE);
                this.monday[i].setText(cursor.getString(0));
                this.monday[i].setBackgroundResource(R.color.color2);
            }
            cursor.moveToNext();
            if(cursor.getString(0).equals("")){
                this.tuesday[i].setTextColor(Color.WHITE);
                this.tuesday[i].setText("가나다라마바사아자차");
            }
            else {
                this.tuesday[i].setTextColor(Color.WHITE);
                this.tuesday[i].setText(cursor.getString(0));
                this.tuesday[i].setBackgroundResource(R.color.color2);
            }
            cursor.moveToNext();
            if(cursor.getString(0).equals("")){
                this.wednesday[i].setTextColor(Color.WHITE);
                this.wednesday[i].setText("가나다라마바사아자차");
            }
            else {
                this.wednesday[i].setTextColor(Color.WHITE);
                this.wednesday[i].setText(cursor.getString(0));
                this.wednesday[i].setBackgroundResource(R.color.color2);
            }
            cursor.moveToNext();
            if(cursor.getString(0).equals("")){
                this.thursday[i].setTextColor(Color.WHITE);
                this.thursday[i].setText("가나다라마바사아자차");
            }
            else {
                this.thursday[i].setTextColor(Color.WHITE);
                this.thursday[i].setText(cursor.getString(0));
                this.thursday[i].setBackgroundResource(R.color.color2);
            }
            cursor.moveToNext();
            if(cursor.getString(0).equals("")){
                this.friday[i].setTextColor(Color.WHITE);
                this.friday[i].setText("가나다라마바사아자차");
            }
            else {
                this.friday[i].setTextColor(Color.WHITE);
                this.friday[i].setText(cursor.getString(0));
                this.friday[i].setBackgroundResource(R.color.color2);
            }
        }
    }

    public void onBackPressed(){
        moveTaskToBack(true);
    }

}
