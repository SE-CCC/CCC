package com.seclass.ccc.models;

public class ExitMessage  extends Message {

    public ExitMessage(){
        super.setMessageType(MessageType.EXIT);
    }

}
