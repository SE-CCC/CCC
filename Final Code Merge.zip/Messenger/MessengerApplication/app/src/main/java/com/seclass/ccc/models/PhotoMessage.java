package com.seclass.ccc.models;

import lombok.Data;

@Data
public class PhotoMessage extends Message {
    private String photoUrl;
}
