package com.seclass.ccc.models;

import lombok.Data;

@Data
public class TextMessage extends Message{
    private String messageText;
}
