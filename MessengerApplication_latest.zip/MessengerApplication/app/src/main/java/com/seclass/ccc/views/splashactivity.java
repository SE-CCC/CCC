package com.seclass.ccc.views;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.seclass.ccc.R;
import com.seclass.ccc.views.MainActivity;

public class splashactivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splashactivity);
        Thread mythread=new Thread(){
            @Override
          public void run(){
                try
                {
                    sleep(3000);
                    Intent myintent=new Intent(splashactivity.this, LoginActivity.class);
                    startActivity(myintent);
                    splashactivity.this.finish();
                }
                catch (InterruptedException e)
                {
                    e.printStackTrace();
                }
            }
        };
        mythread.start();
    }
}
